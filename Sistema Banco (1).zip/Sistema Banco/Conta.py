from Historico import Historico
class Conta():
    def __init__(self, numero, cliente, saldo ):
        self.numero = numero
        self.titular = cliente
        self.saldo = saldo
        self.historico = Historico()

    def sacar (self,valor):
        if (self.saldo >= valor):
            self.saldo -= valor
            print (f'saldo é {self.saldo}')
            self.historico.historico.append(f'Saque realizado: {valor}')
        else:
            print (f'Você está sem saldo {self.saldo}')
        

    def deposita (self,valor):
        self.saldo += valor
        self.historico.historico.append(f'Deposito realizado: {valor}')

    def exibir (self):
        print (f'Conta: {self.numero}\n Nome: {self.titular.nome}\n Saldo: {self.saldo}')

    def trasfere(self, destino, valor):
        if (self.saldo >= valor):
            self.saldo -= valor
            destino.saldo += valor
            self.historico.historico.append(f'Transferencia realizada: {valor}')
            destino.historico.historico.append(f'Transferencia recebida: {valor}')
        else:
            print (f'Saldo isuficiente {self.saldo}')



    
