from Cliente import *
from Conta import  *


if __name__ == '__main__':
  cliente = Cliente('Leandro ',' Loffeu','111-111-111-11')
  conta =  Conta('123-4',cliente,2000.00)
  cliente2 = Cliente('ana','loffeu','222-222-222-22')
  conta2 = Conta('234-5',cliente2,100.00)

  cliente.imprimir()
  conta.exibir()
  cliente2.imprimir()
  conta2.sacar(50)
  conta.trasfere(conta2,50)
  cliente.imprimir()
  conta.exibir()
  conta2.exibir()
  conta.historico.extrato()
  conta2.historico.extrato()