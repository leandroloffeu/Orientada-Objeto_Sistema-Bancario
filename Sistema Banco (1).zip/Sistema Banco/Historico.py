from datetime import datetime
class Historico:
    def __init__(self):
        self.data = datetime.today()
        self.historico = []
    
    def extrato (self):
        for i in self.historico:
            print(i)